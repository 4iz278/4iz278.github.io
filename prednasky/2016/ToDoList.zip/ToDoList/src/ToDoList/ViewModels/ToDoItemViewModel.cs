﻿namespace ToDoList.ViewModels
{
    public class ToDoItemViewModel
    {

        public string Text { get; set; }

        public bool IsCompleted { get; set; }
        public int Id { get; set; }
    }
}