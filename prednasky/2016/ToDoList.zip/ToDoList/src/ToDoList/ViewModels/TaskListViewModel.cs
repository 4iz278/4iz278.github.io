﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToDoList.ViewModels
{
    public class TaskListViewModel
    {

        public string NewTaskText { get; set; }

        public List<ToDoItemViewModel> ToDoItems { get; set; } = new List<ToDoItemViewModel>();

    }
}
