﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using ToDoList.Models;
using ToDoList.ViewModels;

namespace ToDoList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext db;

        public HomeController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public ActionResult Index()
        {
            //var model = new TaskListViewModel()
            //{
            //    NewTaskText = "nazdar",
            //    ToDoItems = new List<ToDoItemViewModel>()
            //    {
            //        new ToDoItemViewModel()
            //        {
            //            Text = "Dorazit na VŠE",
            //            IsCompleted = true
            //        },
            //        new ToDoItemViewModel()
            //        {
            //            Text = "Odvykládat přednášku",
            //            IsCompleted = false
            //        }
            //    }
            //};

            var model = new TaskListViewModel();
            foreach (var item in db.ToDoItems)
            {
                model.ToDoItems.Add(new ToDoItemViewModel()
                {
                    Text = item.Text,
                    IsCompleted = item.CompletedDate != null,
                    Id = item.Id
                });
            }

            return View("Index", model);
        }

        public IActionResult NewTask(string NewTaskText)
        {
            var toDoItem = new ToDoItem()
            {
                Text = NewTaskText
            };
            db.ToDoItems.Add(toDoItem);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult CompleteTask(int id)
        {
            var toDoItem = db.ToDoItems.Single(t => t.Id == id);
            toDoItem.CompletedDate = DateTime.UtcNow;
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
